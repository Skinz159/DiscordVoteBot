import json
import os
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import logging
from config import Config

logger = logging.getLogger(__name__)

class VoteManager:
    def __init__(self):
        self.data_file = Config.VOTES_DATA_FILE
        self.votes_data = self.load_votes_data()
    
    def load_votes_data(self) -> Dict:
        """Load votes data from JSON file"""
        if not os.path.exists(self.data_file):
            # Create directory if it doesn't exist
            os.makedirs(os.path.dirname(self.data_file), exist_ok=True)
            return {
                'users': {},
                'total_votes': 0,
                'last_reset': datetime.now().isoformat()
            }
        
        try:
            with open(self.data_file, 'r') as f:
                return json.load(f)
        except (json.JSONDecodeError, FileNotFoundError) as e:
            logger.error(f'Error loading votes data: {e}')
            return {
                'users': {},
                'total_votes': 0,
                'last_reset': datetime.now().isoformat()
            }
    
    def save_votes_data(self):
        """Save votes data to JSON file"""
        try:
            with open(self.data_file, 'w') as f:
                json.dump(self.votes_data, f, indent=2)
        except Exception as e:
            logger.error(f'Error saving votes data: {e}')
    
    def get_user_data(self, user_id: str) -> Dict:
        """Get user voting data"""
        if user_id not in self.votes_data['users']:
            self.votes_data['users'][user_id] = {
                'total_votes': 0,
                'last_vote': None,
                'current_streak': 0,
                'best_streak': 0,
                'votes_today': 0,
                'last_vote_date': None,
                'site_votes': {},
                'total_points': 0
            }
        return self.votes_data['users'][user_id]
    
    def can_vote(self, user_id: str, site: str = "") -> tuple[bool, str]:
        """Check if user can vote"""
        user_data = self.get_user_data(user_id)
        now = datetime.now()
        
        # La limite quotidienne est désactivée (commentée)
        # if user_data['last_vote_date']:
        #     last_vote_date = datetime.fromisoformat(user_data['last_vote_date'])
        #     if last_vote_date.date() == now.date():
        #         if user_data['votes_today'] >= Config.DAILY_VOTE_LIMIT:
        #             return False, f"Limite quotidienne de votes atteinte ({Config.DAILY_VOTE_LIMIT} vote par jour)"
        
        # Check site-specific cooldown
        if site and site in user_data['site_votes']:
            last_site_vote = datetime.fromisoformat(user_data['site_votes'][site]['last_vote'])
            cooldown_end = last_site_vote + timedelta(seconds=Config.VOTE_COOLDOWN)
            if now < cooldown_end:
                remaining = cooldown_end - now
                hours = int(remaining.total_seconds() // 3600)
                minutes = int((remaining.total_seconds() % 3600) // 60)
                return False, f"Délai actif pour {site}. Réessayez dans {hours}h {minutes}m"
        
        return True, "Peut voter"
    
    def record_vote(self, user_id: str, site: str, username: str = "") -> Dict:
        """Record a vote and calculate rewards"""
        user_data = self.get_user_data(user_id)
        now = datetime.now()
        
        # Update vote counts
        user_data['total_votes'] += 1
        user_data['last_vote'] = now.isoformat()
        
        # Handle daily votes
        if user_data['last_vote_date']:
            last_vote_date = datetime.fromisoformat(user_data['last_vote_date'])
            if last_vote_date.date() != now.date():
                user_data['votes_today'] = 1
            else:
                user_data['votes_today'] += 1
        else:
            user_data['votes_today'] = 1
        
        user_data['last_vote_date'] = now.isoformat()
        
        # Handle streaks
        if user_data['last_vote_date']:
            last_date = datetime.fromisoformat(user_data['last_vote_date']).date()
            yesterday = (now - timedelta(days=1)).date()
            
            if last_date == yesterday:
                user_data['current_streak'] += 1
            elif last_date == now.date():
                pass  # Same day, don't change streak
            else:
                user_data['current_streak'] = 1
        else:
            user_data['current_streak'] = 1
        
        if user_data['current_streak'] > user_data['best_streak']:
            user_data['best_streak'] = user_data['current_streak']
        
        # Record site-specific vote
        if site not in user_data['site_votes']:
            user_data['site_votes'][site] = {
                'count': 0,
                'last_vote': None
            }
        
        user_data['site_votes'][site]['count'] += 1
        user_data['site_votes'][site]['last_vote'] = now.isoformat()
        
        # Calculate rewards
        base_points = Config.VOTE_SITES.get(site, {}).get('reward_points', Config.BASE_REWARD_POINTS)
        streak_bonus = int(base_points * (Config.STREAK_BONUS_MULTIPLIER ** (user_data['current_streak'] - 1)) - base_points)
        total_points = base_points + streak_bonus
        
        user_data['total_points'] += total_points
        
        # Update global stats
        self.votes_data['total_votes'] += 1
        
        # Save data
        self.save_votes_data()
        
        return {
            'base_points': base_points,
            'streak_bonus': streak_bonus,
            'total_points': total_points,
            'current_streak': user_data['current_streak'],
            'username': username
        }
    
    def get_leaderboard(self, limit: int = 10) -> List[Dict]:
        """Get voting leaderboard"""
        users = []
        for user_id, data in self.votes_data['users'].items():
            users.append({
                'user_id': user_id,
                'total_votes': data['total_votes'],
                'total_points': data['total_points'],
                'current_streak': data['current_streak'],
                'best_streak': data['best_streak']
            })
        
        # Sort by total points, then by total votes
        users.sort(key=lambda x: (x['total_points'], x['total_votes']), reverse=True)
        return users[:limit]
    
    def get_user_stats(self, user_id: str) -> Dict:
        """Get detailed user statistics"""
        user_data = self.get_user_data(user_id)
        
        # Calculate rank
        leaderboard = self.get_leaderboard(1000)  # Get more entries for accurate ranking
        rank = None
        for i, user in enumerate(leaderboard):
            if user['user_id'] == user_id:
                rank = i + 1
                break
        
        return {
            'total_votes': user_data['total_votes'],
            'total_points': user_data['total_points'],
            'current_streak': user_data['current_streak'],
            'best_streak': user_data['best_streak'],
            'votes_today': user_data['votes_today'],
            'rank': rank,
            'site_votes': user_data['site_votes']
        }
    
    def get_global_stats(self) -> Dict:
        """Get global voting statistics"""
        total_users = len(self.votes_data['users'])
        total_votes = self.votes_data['total_votes']
        
        # Find top voter
        leaderboard = self.get_leaderboard(1)
        top_voter = leaderboard[0] if leaderboard else None
        
        return {
            'total_users': total_users,
            'total_votes': total_votes,
            'top_voter': top_voter
        }
