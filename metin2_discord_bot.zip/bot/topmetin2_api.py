import aiohttp
import logging
from config import Config

logger = logging.getLogger(__name__)

class TopMetin2API:
    def __init__(self):
        self.api_key = Config.TOPMETIN2_API_KEY
        self.server_id = "445"  # Empire de l'Ombre server ID
        
    async def check_vote(self, discord_id: str) -> dict:
        """Check if user has voted on Top-Metin2"""
        try:
            async with aiohttp.ClientSession() as session:
                headers = {
                    'Authorization': f'Bearer {self.api_key}',
                    'Content-Type': 'application/json'
                }
                
                # Check vote status for specific server
                url = f"https://top-metin2.org/api/server/{self.server_id}/vote/check"
                params = {'discord_id': discord_id}
                
                async with session.get(url, headers=headers, params=params) as response:
                    if response.status == 200:
                        data = await response.json()
                        return {
                            'success': True,
                            'has_voted': data.get('has_voted', False),
                            'vote_time': data.get('vote_time'),
                            'can_vote_again': data.get('can_vote_again'),
                            'message': 'Vote check successful'
                        }
                    elif response.status == 404:
                        # User hasn't voted yet
                        return {
                            'success': True,
                            'has_voted': False,
                            'message': 'User has not voted yet'
                        }
                    else:
                        logger.error(f'Top-Metin2 API error: {response.status}')
                        return {
                            'success': False,
                            'error': f'API returned status {response.status}'
                        }
                        
        except Exception as e:
            logger.error(f'Error checking Top-Metin2 vote: {e}')
            return {
                'success': False,
                'error': str(e)
            }
    
    async def get_vote_link(self, discord_id: str = None) -> str:
        """Get vote link for Empire de l'Ombre"""
        base_url = f"https://top-metin2.org/in/{self.server_id}-empire-de-l-ombre/"
        if discord_id:
            return f"{base_url}?discord={discord_id}"
        return base_url
    
    async def confirm_vote(self, discord_id: str) -> dict:
        """Confirm vote and get reward status"""
        try:
            async with aiohttp.ClientSession() as session:
                headers = {
                    'Authorization': f'Bearer {self.api_key}',
                    'Content-Type': 'application/json'
                }
                
                url = f"https://top-metin2.org/api/server/{self.server_id}/vote/confirm"
                data = {'discord_id': discord_id}
                
                async with session.post(url, headers=headers, json=data) as response:
                    if response.status == 200:
                        result = await response.json()
                        return {
                            'success': True,
                            'verified': True,
                            'message': result.get('message', 'Vote confirmed successfully')
                        }
                    elif response.status == 400:
                        return {
                            'success': False,
                            'verified': False,
                            'error': 'Vote not found or already confirmed'
                        }
                    else:
                        return {
                            'success': False,
                            'verified': False,
                            'error': f'API error: {response.status}'
                        }
                        
        except Exception as e:
            logger.error(f'Error confirming vote: {e}')
            return {
                'success': False,
                'verified': False,
                'error': str(e)
            }