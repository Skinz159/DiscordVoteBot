import discord
from datetime import datetime, timedelta
from config import Config

def create_embed(title: str, description: str = "", color: int = 0) -> discord.Embed:
    """Create a standard embed with consistent styling"""
    if color == 0:
        color = Config.COLORS['info']
    
    embed = discord.Embed(
        title=title,
        description=description,
        color=color,
        timestamp=datetime.now()
    )
    return embed

def create_vote_embed(site_name: str, site_url: str, reward_info: dict = {}) -> discord.Embed:
    """Create an embed for vote information"""
    embed = create_embed(
        title=f"{Config.EMOJIS['vote']} Vote for our server!",
        description=f"Click the link below to vote on **{site_name}**",
        color=Config.COLORS['info']
    )
    
    embed.add_field(
        name="Vote Link",
        value=f"[Vote on {site_name}]({site_url})",
        inline=False
    )
    
    if reward_info:
        embed.add_field(
            name=f"{Config.EMOJIS['coin']} Rewards",
            value=f"**Base Points:** {reward_info.get('base_points', 0)}\n"
                  f"**Streak Bonus:** {reward_info.get('streak_bonus', 0)}\n"
                  f"**Total Points:** {reward_info.get('total_points', 0)}",
            inline=True
        )
        
        if reward_info.get('current_streak', 0) > 1:
            embed.add_field(
                name=f"{Config.EMOJIS['fire']} Current Streak",
                value=f"{reward_info['current_streak']} days",
                inline=True
            )
    
    embed.set_footer(text="Thank you for supporting our server!")
    return embed

def create_stats_embed(user_stats: dict, user_name: str) -> discord.Embed:
    """Create an embed for user statistics"""
    embed = create_embed(
        title=f"{Config.EMOJIS['star']} Statistiques de Vote pour {user_name}",
        color=Config.COLORS['info']
    )
    
    # Main stats
    embed.add_field(
        name="📊 Statistiques Générales",
        value=f"**Total Votes :** {user_stats['total_votes']}\n"
              f"**Total Points :** {user_stats['total_points']}\n"
              f"**Rang Serveur :** #{user_stats['rank'] or 'Non classé'}",
        inline=True
    )
    
    # Streak info
    embed.add_field(
        name=f"{Config.EMOJIS['fire']} Info Série",
        value=f"**Série Actuelle :** {user_stats['current_streak']} jours\n"
              f"**Meilleure Série :** {user_stats['best_streak']} jours\n"
              f"**Votes Aujourd'hui :** {user_stats['votes_today']}/{Config.DAILY_VOTE_LIMIT}",
        inline=True
    )
    
    # Site-specific votes
    if user_stats['site_votes']:
        site_info = []
        for site, data in user_stats['site_votes'].items():
            site_name = Config.VOTE_SITES.get(site, {}).get('name', site.title())
            site_info.append(f"**{site_name} :** {data['count']} votes")
        
        embed.add_field(
            name="🌐 Votes par Site",
            value="\n".join(site_info) if site_info else "Aucun vote pour le moment",
            inline=False
        )
    
    return embed

def create_leaderboard_embed(leaderboard: list, bot) -> discord.Embed:
    """Create an embed for the voting leaderboard"""
    embed = create_embed(
        title=f"{Config.EMOJIS['trophy']} Classement des Votes",
        description="Meilleurs votants du mois",
        color=Config.COLORS['success']
    )
    
    if not leaderboard:
        embed.add_field(
            name="Aucune Donnée",
            value="Aucun vote enregistré pour le moment. Soyez le premier à voter !",
            inline=False
        )
        return embed
    
    # Préchargement des membres pour tous les serveurs
    member_cache = {}
    for guild in bot.guilds:
        # Forcer le bot à mettre à jour la liste des membres du serveur
        try:
            for member in guild.members:
                member_id = str(member.id)
                # Stocker les infos membres dans notre cache
                if member_id not in member_cache:
                    member_cache[member_id] = member
        except Exception as e:
            continue
    
    leaderboard_text = []
    for i, user_data in enumerate(leaderboard[:10]):
        rank_emoji = ["👑", "🥈", "🥉"][i] if i < 3 else f"{i+1}."
        user_id = user_data['user_id']
        
        # Par défaut, on utilise un nom générique
        username = f"Utilisateur#{user_id[-4:]}"
        
        # Récupérer le pseudo depuis notre cache préchargé
        if user_id in member_cache:
            username = member_cache[user_id].display_name
        else:
            # Chercher le membre dans tous les serveurs
            for guild in bot.guilds:
                try:
                    member = guild.get_member(int(user_id))
                    if member:
                        username = member.display_name
                        break
                except:
                    continue
            
            # Si on n'a pas trouvé, essayer avec l'API utilisateur
            if username == f"Utilisateur#{user_id[-4:]}":
                try:
                    user = bot.get_user(int(user_id))
                    if user:
                        username = user.display_name
                except:
                    pass
        
        leaderboard_text.append(
            f"{rank_emoji} **{username}**\n"
            f"   {Config.EMOJIS['coin']} {user_data['total_points']} points "
            f"({user_data['total_votes']} votes)"
        )
    
    embed.add_field(
        name="Meilleurs Votants",
        value="\n\n".join(leaderboard_text),
        inline=False
    )
    
    return embed

def format_cooldown_time(seconds: int) -> str:
    """Format cooldown time in a readable format"""
    if seconds <= 0:
        return "Ready to vote!"
    
    hours = seconds // 3600
    minutes = (seconds % 3600) // 60
    
    if hours > 0:
        return f"{hours}h {minutes}m remaining"
    else:
        return f"{minutes}m remaining"

def get_next_vote_time(last_vote_time: str) -> str:
    """Calculate when user can vote next"""
    if not last_vote_time:
        return "Ready to vote!"
    
    last_vote = datetime.fromisoformat(last_vote_time)
    next_vote = last_vote + timedelta(seconds=Config.VOTE_COOLDOWN)
    now = datetime.now()
    
    if now >= next_vote:
        return "Ready to vote!"
    
    remaining = next_vote - now
    return format_cooldown_time(int(remaining.total_seconds()))
